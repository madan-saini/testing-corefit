from django.conf import settings # import the settings file

def constant(request):
    # return the value you want as a dictionnary. you may add multiple values in there.
    context = {
        'LOGO': 'static/images/logo-before-login.png',
        'HTTP_PATH': 'http://127.0.0.1:8000',
        'SITE_TITLE': 'CoreFit',
        'TITLE': 'CoreFit | ',
        'user_list' : {
            'Personal Trainer' : 'Personal Trainer',
            'Gym or Studio' : 'Gym or Studio',
            'Sports Coach' : 'Sports Coach',
            'Sports Facility' : 'Sports Facility',
            'Health & Wellness Individual' : 'Health & Wellness Individual',
            'Health & Wellness Company' : 'Health & Wellness Company',
            'Personal Training Company' : 'Personal Training Company',
            'Sports Coaching Company' : 'Sports Coaching Company',
        }
    }
    return context
