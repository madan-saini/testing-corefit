from django.shortcuts import render
from .. models import *
from django.http import HttpResponse
from django.conf import settings
from django.core.mail import *
import math
from django.contrib.auth.hashers import make_password
import random
from django.contrib.auth.hashers import *
from django.core.signing import Signer
from django.contrib.auth.hashers import PBKDF2PasswordHasher
import random
from django.utils.text import slugify
import string
import json
from django.contrib import messages
from datetime import datetime
from django.shortcuts import redirect
from django.http import HttpResponseRedirect
from smtplib import SMTP 
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from jinja2 import Environment, FileSystemLoader
from django.template.loader import get_template
from . send_email import *

import os
# Create your views here.

# def __init__(self):
#     Flask.redirect('/profile', 301)

env = Environment(
    loader=FileSystemLoader('%s/../templates/emails/' % os.path.dirname(__file__)))

def rand_slug():
    return ''.join(random.choice(string.ascii_letters) for _ in range(15))

def logout(request):
    del request.session['user_id']
    return redirect("login")


def login(request):
    title = 'Login'
    
    user = User.objects
    if request.method == 'POST':
        email = request.POST['email']
        password = request.POST['password']
        emailCheck = user.filter(email_address=email)

        if bool(emailCheck):
            auth = user.get(email_address=email)
            datas = check_password(password, auth.password)
            if datas:
                request.session['user_id'] = auth.id
                user_id = request.session['user_id']

                # print(request.POST['user_remember'])

                # response.set_cookie('cookie_name', 'cookie_value')
                return HttpResponse(1)
            else:
                messages.error(
                    request, f"Invalid email or password")
                return HttpResponse(0)
        else:
            messages.error(
                    request, f"Invalid email or password")
            return HttpResponse(0)

        # print(datas)
        # return HttpResponse(json_string)
    # user = User.objects.get()
    context = {
        # 'users': user,
        'pageTitle': title
    }
    return render(request, 'users/login.html', context)

def forgotPassword(request):
    title = 'Forgot Password'
    user = User.objects
    
    if request.method == 'POST':
        email = request.POST['email']
        emailCheck = user.filter(email_address=email)

        if bool(emailCheck):
            auth = user.get(email_address=email)
            user_name = auth.first_name+' '+auth.last_name
            # user_id = request.session['user_id']
            # return HttpResponse(1)

            otp = generateOTP()
            request.session['otp'] = ''
            signer = Signer()
            encrypthOTP = make_password(otp)
            request.session['otp'] = encrypthOTP
            sessionOtp = request.session['otp']

            emailtemplate = Emailtemplate.objects
            emailTemplateData = emailtemplate.get(id=3)

            email_subject = emailTemplateData.subject
            email_template = emailTemplateData.template

            edits = [('[!username!]', user_name), ('[!SITE_TITLE!]', settings.SITE_TITLE),('[!OTP!]',otp),('[!REPLY_EMAIL!]',settings.REPLY_EMAIL),('[!MAIL_SIGNATURE!]',settings.MAIL_SIGNATURE)]
            for search, replace in edits:
                email_template = email_template.replace(search, replace)

            data = []
            data.append(
                {
                    'template': email_template,
                    "logo": settings.HTTP_PATH + '/' +settings.LOGO_INNER,
                    'HTTP_PATH': settings.HTTP_PATH,
                    'SITE_TITLE': settings.SITE_TITLE
                    
                })
            jsonData = data
            template = env.get_template('email_template.html')
            output = template.render(data=jsonData[0])

            send_mail(email, email_subject, output)  
            return HttpResponse(0)
        else:
            messages.error(
                    request, f"Invalid email address")
            return HttpResponse(1)

        # print(datas)
        # return HttpResponse(json_string)
    # user = User.objects.get()
    context = {
        # 'users': user,
        'pageTitle': title
    }
    return render(request, 'users/forgot-password.html', context)

def resetPassword(request, slug):
    title = 'Reset Password'
    user = User.objects

    
    emailCheck = user.filter(uniqueKey=slug)

    if bool(emailCheck):
        if request.method == 'POST':
            password = request.POST['password']

            auth = user.get(uniqueKey=slug)
            datas = check_password(password, auth.password)
            
            if datas:
                # messages.error(
                #     request, f"You cannot put your old password as new password, please use another password.")
                return HttpResponse(0)
            else:
                password=make_password(password)

                uniqueKey = ''
                User.objects.filter(uniqueKey=slug).update(uniqueKey=uniqueKey,password=password)  

                messages.success(
                        request, f"Password updated successfully.")
                return HttpResponse(1)
            
        context = {
            # 'users': user,
            'pageTitle': title,
            'slug':slug
        }
        return render(request, 'users/reset-password.html', context)
    else:
        print(45654)
        return HttpResponseRedirect('/login')

def checkValid(request):
    emailId = request.POST.get("serializedData[email]")    
    emailCheck = User.objects.filter(email_address=emailId)
    phone = request.POST.get("serializedData[phone]")    
    # terms = request.POST.get("serializedData[terms]")    
    # print(emailId)
    # print(terms)
    # return HttpResponse(request.POST.get("serializedData[phone]"))
    phoneCheck = User.objects.filter(contact=phone)
    if bool(emailCheck) == False:
        if bool(phoneCheck) == False:
            return HttpResponse('0')
        else:
            return HttpResponse('Phone number already exist')
    else:
        return HttpResponse('Email address already exist')

def register(request):
    title = 'Registration'

    if request.method == 'POST':
        data = request.POST

        users = User(
            email_address=data.get("serializedData[email]"),
            contact=data.get("serializedData[phone]"),
            first_name=data.get("serializedData[first_name]"),
            last_name=data.get("serializedData[last_name]"),
            user_type=data.get("serializedData[user_type]"),
            password=make_password(data.get("serializedData[password]")),
            
            slug=slugify(data.get("serializedData[first_name]") + "-" + rand_slug()),
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow(),
        )
        users.save()

        messages.success(
                    request, f"Your account has been registered successfully. You can login now.")
        return HttpResponse(users)

    context = {
        'pageTitle': title
    }
    return render(request, 'users/register.html', context)

def generateOTP():
    digits = "0123456789"
    OTP = ""
    for i in range(6):
        OTP += digits[math.floor(random.random() * 10)]
    return OTP

def otp_send(request):
    emailId = request.POST.get("email")
    
    otp = generateOTP()
    request.session['otp'] = ''
    encrypthOTP = make_password(otp)
    request.session['otp'] = encrypthOTP

    user = User.objects
    auth = user.get(email_address=emailId)
    user_name = auth.first_name+' '+auth.last_name
    emailtemplate = Emailtemplate.objects
    emailTemplateData = emailtemplate.get(id=3)

    email_subject = emailTemplateData.subject
    email_template = emailTemplateData.template

    edits = [('[!username!]', user_name), ('[!SITE_TITLE!]', settings.SITE_TITLE),('[!OTP!]',otp),('[!REPLY_EMAIL!]',settings.REPLY_EMAIL),('[!MAIL_SIGNATURE!]',settings.MAIL_SIGNATURE)]
    for search, replace in edits:
        email_template = email_template.replace(search, replace)

    data = []
    data.append(
        {
            'template': email_template,
            "logo": settings.HTTP_PATH + '/' +settings.LOGO_INNER,
            'HTTP_PATH': settings.HTTP_PATH,
            'SITE_TITLE': settings.SITE_TITLE
            
        })
    jsonData = data
    template = env.get_template('email_template.html')
    output = template.render(data=jsonData[0])

    send_mail(emailId, email_subject, output) 
    return HttpResponse(1)

def otp_verify(request):
    otp1 = request.POST.get("serializedData[otp_code]")
    otp2 = request.POST.get("serializedData[otp_code1]")
    otp3 = request.POST.get("serializedData[otp_code2]")
    otp4 = request.POST.get("serializedData[otp_code3]")
    otp5 = request.POST.get("serializedData[otp_code4]")
    otp6 = request.POST.get("serializedData[otp_code5]")
    
    
    checkOtp=otp1+otp2+otp3+otp4+otp5+otp6
    
    sessionOtp = request.session['otp']
    if check_password(checkOtp, sessionOtp):       
        return HttpResponse(1)
    else:
        return HttpResponse(0)

def forgot_otp_verify(request):
    otp1 = request.POST.get("serializedData[otp_code]")
    otp2 = request.POST.get("serializedData[otp_code1]")
    otp3 = request.POST.get("serializedData[otp_code2]")
    otp4 = request.POST.get("serializedData[otp_code3]")
    otp5 = request.POST.get("serializedData[otp_code4]")
    otp6 = request.POST.get("serializedData[otp_code5]")

    email = request.POST.get("serializedData[email]")
    uniqueKey = rand_slug()
    
    checkOtp=otp1+otp2+otp3+otp4+otp5+otp6
    
    sessionOtp = request.session['otp']
    if check_password(checkOtp, sessionOtp):     

        User.objects.filter(email_address=email).update(uniqueKey=uniqueKey)  
        return HttpResponse(uniqueKey)
    else:
        return HttpResponse(0)

def index(request):
    title = 'Index'
    
    context = {
        # 'users': user,
        'pageTitle': title
    }
    return render(request, 'users/index.html', context)

def profile(request):
    title = 'Profile'
    
    context = {
        # 'users': user,
        'pageTitle': title
    }
    return render(request, 'users/index.html', context)
