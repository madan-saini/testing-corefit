from django.db import models

# Create your models here.
class User(models.Model):
    email_address = models.EmailField(unique=True)
    first_name = models.Field()
    last_name = models.Field()
    contact = models.Field()
    user_type = models.Field()
    allow_promotion = models.Field()
    uniqueKey = models.Field()
    nationality = models.Field()
    password = models.Field()
    slug = models.Field()
    created_at = models.Field()
    updated_at = models.Field()
    
    class Meta:
        db_table = "users"

class Country(models.Model):

    name = models.Field()
    country_code = models.Field()
    sortname = models.Field()

    def __str__(self):
        return self.name
    class Meta:
        db_table = "countries"

class Emailtemplate(models.Model):

    subject = models.Field()
    template = models.Field()

    class Meta:
        db_table = "emailtemplates"
        
        





        