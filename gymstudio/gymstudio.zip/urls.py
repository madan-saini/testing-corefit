
from django.contrib import admin
from django.urls import path
from . controller import userViews

urlpatterns = [
     path('login', userViews.login,name="login"), 
     path('forgot-password', userViews.forgotPassword,name="forgot-password"), 
     path('reset-password/<slug:slug>', userViews.resetPassword,name="reset-password"), 
     path('checkValid', userViews.checkValid,name="checkValid"), 
     path('register', userViews.register,name="register"), 
     path('otp_send', userViews.otp_send,name="otp_send"),
     path('otp_verify', userViews.otp_verify,name="otp_verify"),
     path('forgot_otp_verify', userViews.forgot_otp_verify,name="forgot_otp_verify"),
     path('profile', userViews.profile,name="profile"),
     path('logout', userViews.logout,name="logout"),
     path('', userViews.login,name="login"),
]
